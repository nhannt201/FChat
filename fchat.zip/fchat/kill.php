<?php
$content = "";
$handle = fopen ("chat.txt","w");
fwrite ($handle, $content);  