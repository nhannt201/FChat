<?php
header('Content-Type: text/html; charset=UTF-8');
include 'chat.txt';

?>