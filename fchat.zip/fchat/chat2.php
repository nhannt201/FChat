<?php
header('Content-Type: text/html; charset=UTF-8');
$content = $_GET["nick"]." : ".$_GET["text"]."\n";
$handle = fopen ("txt.txt","w");
fwrite ($handle, $content);  