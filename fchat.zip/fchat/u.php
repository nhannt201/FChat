<?php
$name = $_GET["msm"];
$content = $_GET["nick"];
$handle = fopen ("user/".$name.".txt","w");
fwrite ($handle, $content);  
?>