<?php
header('Content-Type: text/html; charset=UTF-8');
$content = $_GET["nick"]." : ".$_GET["text"]."\n";
$handle = fopen ("chat.txt","a+");
fwrite ($handle, $content);  